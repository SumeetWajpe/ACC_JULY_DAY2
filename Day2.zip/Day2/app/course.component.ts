import {Component,Input} from '@angular/core';

@Component({
    selector:'course',
    template:`<h2> {{courseName}} </h2>
    
    `
})
export class CourseComponent{
  @Input('name')  courseName:string="Node";
}

 