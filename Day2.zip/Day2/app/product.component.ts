import {Component,Input} from '@angular/core';

import {Product} from './product';

@Component({
    selector:'product',
    template:`<div>
    <h2>{{productDetails.name}} </h2>
    <img [src]="productDetails.imageUrl" height="100px" width="100px" /> <br/>
    <b>Price : </b> {{productDetails.price}} <br/>
    <b>Quantity : </b> {{productDetails.quantity}} <br/>
    
        </div>`
})
export class ProductComponent{
 @Input('pdetails')   productDetails:Product;
}