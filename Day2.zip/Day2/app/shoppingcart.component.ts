import {Component} from '@angular/core';
import {Product} from './product';

@Component({
    selector:'shoppingcart',
    template:`
        <product [pdetails]="product1"></product>
      
    `
})
export class ShoppingCartComponent{
  // product1:any={name:'Mobile',price:20000,quantity:10}

product1:Product;

constructor(){
    this.product1 = new Product(
        "Mobile",
        40000,
        10,
        'http://neowebsolution.com/rupak/nancy_mobile/wp-content/uploads/2016/09/Mobile-Phones.jpg'
    );
}
}